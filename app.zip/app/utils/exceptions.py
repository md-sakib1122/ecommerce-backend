# Custom exception classes + handlers
